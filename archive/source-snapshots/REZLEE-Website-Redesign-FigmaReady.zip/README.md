# REZLEE — Intelligent Commerce Prototype

A React + TypeScript + Vite prototype with two connected surfaces:

- Customer storefront: product discovery, expanded catalog, product Q&A, comparisons, compatibility context, alternatives, and bundles.
- Merchant workspace: operational overview, inventory control, catalog pricing, opportunities, AI-assisted proposal workflow, approvals, analytics, rules, and activity history.

## Run

```bash
npm install
npm run dev
```

## Important prototype notes

The 65-product catalog and all merchant analytics are synthetic demonstration data. The advisor and merchant copilot are deterministic local simulations. Authentication, database persistence, live AI providers, payments, and external operations are not connected. Changes reset on reload.

See [docs/rezlee-redesign.md](docs/rezlee-redesign.md) for the design and implementation notes.
