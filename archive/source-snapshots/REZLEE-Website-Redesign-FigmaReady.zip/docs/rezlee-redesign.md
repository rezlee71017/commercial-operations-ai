# REZLEE storefront and merchant workspace refresh

## Design direction
- Reframed REZLEE as a broader, expandable brand rather than a store tied to one product category.
- Customer-facing experience uses a warm editorial surface, Ink & Coral as the primary palette, restrained teal/amber accents, larger product photography, clearer hierarchy, and a wider collection-first navigation.
- Merchant workspace uses a separate dark Ink / Deep Teal environment with coral action accents and teal-positive states. The two surfaces share brand DNA without sharing the same visual density or operating mode.
- Alibaba-inspired breadth and category navigation are combined with Apple's restrained typography, whitespace, and product presentation. No direct layouts or assets are copied.

## Customer experience
- Expanded the fictional catalog from 20 to 65 products across seven collections: Audio & Sound, Mobile & Power, Computing & Workspace, Smart Home & Security, Automotive Gadgets, Travel & Portable Tech, and Creator & Photography.
- Added collection counts, broader product grids, richer filtering and search, same-type comparison, product detail Q&A, compatibility checks, complementary products, alternatives, budget-aware recommendations, and bundle discovery.
- Extended deterministic advisor parsing to recognize more product types and shopping intents, prioritize declared specification matches, respect budgets, and show alternatives when no exact match is available.
- Product names, specifications, brands, stock, and prices are fictional demo content. Product images are representative editorial photography, not exact SKU imagery.

## Merchant workspace
- Reworked the merchant surface around operational visibility: catalog size, units on hand, retail inventory value, low-stock alerts, illustrative revenue activity, and commercial-health indicators.
- Separated **Inventory** from **Catalog** at both information-architecture and interaction level:
  - Inventory focuses on on-hand units, availability, low/out-of-stock states, stock level, and retail value. Its action adjusts stock only.
  - Catalog focuses on product identity, category, brand, retail price, unit cost, and gross margin. Its action edits pricing only.
- Added distinct Insights panels for a seven-day illustrative revenue series, catalog mix, demo order records, and inventory risk snapshot.
- Preserved opportunities, operations copilot, approvals, policy rules, and activity history. Existing proposal approval still requires human review.

## Data integrity and limitations
- The expanded catalog is synthetic. It is not connected to a supplier feed or real merchant catalog.
- Revenue and order charts use explicitly labeled illustrative demo values. They are not live results, forecasts, customer analytics, or evidence of product demand.
- All state remains in memory and resets on reload. Authentication, database persistence, live AI providers, payments, checkout, fulfillment, supplier purchase orders, and external execution are not connected.
- The customer advisor is deterministic request parsing, not a live LLM. Product Q&A only reads recorded specification fields and explicitly admits when information is missing.
- Reorder forecasting is intentionally not claimed because supplier lead times and purchase-order data are not present.
- Mobile table layouts use horizontal scrolling; physical-device and assistive-technology QA remains recommended.

## Run locally
- Install dependencies with `npm install`.
- Start the dev server with `npm run dev`.
- Create a production build with `npm run build`.
